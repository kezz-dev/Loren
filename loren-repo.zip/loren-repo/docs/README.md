# Loren Documentation

Complete feature reference for Loren, split by area. This was converted from the original single-page docs (`loren-docs.html`) into per-topic Markdown so it's easier to read and diff on GitHub.

- [Panels](panels.md) — the four main navigation panels
- [Book Management](book-management.md) — adding, editing, organizing, folders, duplicates, wishlist
- [Reading Experience](reading-experience.md) — PDF reader, session tracking, insights dashboard
- [Discover](discover.md) — mosaic and genre-shelf browsing
- [Recall (Trivia)](recall-trivia.md) — book trivia game and question types
- [Loren AI](loren-ai.md) — the built-in AI librarian
- [Query Reference](query-reference.md) — every query Loren understands, with examples and responses
- [Proactive Notifications](proactive-notifications.md) — moments where Loren speaks first
- [Observations](observations.md) — in-session behavioral asides
- [Settings](settings.md) — customization options
- [Search](search.md) — how the search bar behaves per panel
