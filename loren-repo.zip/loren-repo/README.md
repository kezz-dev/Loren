# Loren

Loren is an offline-first personal library app: add your own PDFs, and Loren organizes them, tracks your reading, and acts as an AI librarian who knows your collection.

Like the UNILORIN Post-UTME app, Loren ships as a single self-contained HTML file — no build step, no server required. It also includes a basic PWA setup (manifest + service worker) for offline caching and "Add to Home Screen" installs.

## Files

| File | Purpose |
| --- | --- |
| `Loren.html` | The entire app — markup, styles, and JS in one file. This is what you open or host. |
| `manifest.json` | Web app manifest for PWA installability (name, icons, start URL). |
| `sw.js` | Service worker — caches the app shell for offline use, network-first for the HTML document. |
| `docs/` | Full feature documentation, split by area (see below). |

## Running it

Open `Loren.html` directly in a browser, or host the whole repo root on any static host (GitHub Pages, Netlify, Cloudflare Pages). The manifest and service worker both reference `./Loren.html` by name, so keep that filename as-is if you move things around.

**Note:** `manifest.json` references `icon-192.png` and `icon-512.png`, which aren't part of this upload yet — add them at the repo root before relying on the install prompt or home-screen icon.

## Documentation

The `docs/` folder has the full feature reference, converted from the original docs page into per-topic Markdown files:

- [Panels](docs/panels.md) — the four main navigation panels
- [Book Management](docs/book-management.md) — adding, editing, organizing, folders, duplicates, wishlist
- [Reading Experience](docs/reading-experience.md) — PDF reader, session tracking, insights dashboard
- [Discover](docs/discover.md) — mosaic and genre-shelf browsing
- [Recall (Trivia)](docs/recall-trivia.md) — book trivia game and question types
- [Loren AI](docs/loren-ai.md) — the built-in AI librarian
- [Query Reference](docs/query-reference.md) — every query Loren understands, with examples and responses
- [Proactive Notifications](docs/proactive-notifications.md) — moments where Loren speaks first
- [Observations](docs/observations.md) — in-session behavioral asides
- [Settings](docs/settings.md) — customization options
- [Search](docs/search.md) — how the search bar behaves per panel
